Project Summary 
The project shows a system of renting and returning books, and it can be used in libraries and bookstores. We mainly use the binary tree structure which includes other data structures such as dynamic memory, structs and linked lists for this project. We use the tree to build a tree to store the information of book such as the name of books, the authors of books, and the quantity of the book. The project has a menu, and you can make a selection and type the number of the decision after read the menu. By making a selection, you and find books that you want, rent them, see the total books that you decide to rent and return them after finish the books. In addition, if you don’t want rent a book, you can delete them before finish the process. What’s more, you can see the total books list when you don’t know what book you want rent. 

How to Run 
This section contains instructions, with examples, of how to run your program. It’s easy to use because only need to type the number of selection and the title of the book you want. For example, first, you should open the project and run the code. Next, if you want find a book, you should type the number 1 and then type the title of the book. If you don’t know what book you want rent, you can type the number 3 in order to see all the book and find one you want.
Dependencies 
None 
System Requirements 
No system requirement.
 Group Members 
Jiafan QianYuhan Wang 
Contributors 
None
Open issues/bugs 
You should type a number when you make a selection. Please don’t type a string. 
